//
//  FirstViewController.swift
//  TabBarHome
//
//  Created by alumno on 02/02/23.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
