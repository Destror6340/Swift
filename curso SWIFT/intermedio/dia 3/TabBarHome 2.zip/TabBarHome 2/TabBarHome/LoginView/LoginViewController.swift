//
//  LoginViewController.swift
//  TabBarHome
//
//  Created by alumno on 02/02/23.
//

import UIKit

class LoginViewController: UIViewController {
    //MARK: Outlets
    
    
    @IBOutlet weak var SingUpButton: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
