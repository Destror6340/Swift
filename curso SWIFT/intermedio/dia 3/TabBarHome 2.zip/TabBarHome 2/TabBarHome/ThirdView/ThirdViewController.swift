//
//  ThirdViewController.swift
//  TabBarHome
//
//  Created by alumno on 02/02/23.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
