import Foundation

/*
 Proyecto final
 El proyecto final consiste en realizar un programa para una tienda online de Apple (con funcionamiento en la terminal o consola).

 Los requerimientos del programa son los siguientes:
 - Tener un inventario(Instanciado):
        - Productos en general
             - Producto
             - Nombre:
             - Precio:
             - Color:
             - ID(tiene que ser diferente de los productos anteriores):
             - Oferta: (15%, 8%, 10%)
             - Oferta Activada:
             - Disponibilidad

             - Categoría (cada categoría tiene sus)
                 - Ipad
                 - Iphone
                 - Mac
                 - AirPods
                 - Apple Watch

 
     - Tener la posibilidad de realizar ventas.
        - Ingresar el ID
            - Checar si hay existencia y de haberlo borrar la instancia
     - Revisar ofertas.
     - Revisar disponibilidad en productos


     - Tener la posibilidad de registrar un nuevo producto.
        - Instanciar el producto
 */

// Estructura para representar un producto
enum NumerosEnum: Int {
    case ocho = 8
    case diez = 10
    case quince = 15
}

struct Producto {
    let nombre: String
    let precio: Double
    let color: String
    let id: Int
    var oferta: NumerosEnum?
    var ofertaActivada: Bool
    var disponibilidad: Int
}

// Estructura para representar el inventario
struct Inventario {
    var productos: [Producto]
    // Función para registrar un nuevo producto
    mutating func registrarProducto(_ producto: Producto) {
        productos.append(producto)
    }
    //Asignar nueva oferta al producto
    mutating func modificarOfertaProducto(productoID: Int) {
        print("selecciona la oferta: 0, 8, 10, 15%")
        if let ofertaString = readLine(),
           let oferta = NumerosEnum(rawValue: Int(ofertaString) ?? 0) {
            // Si el valor de nuevaOferta no es nulo y se puede convertir a un entero válido
            // y corresponde a un caso de NumerosEnum, entonces lo asignamos a la propiedad oferta
            if let index = productos.firstIndex(where: { $0.id == productoID }) {
                productos[index].oferta = oferta
            }
        } else {
            // Si nuevaOferta es nula o no se puede convertir a un entero válido o no corresponde
            // a un caso de NumerosEnum, entonces asignamos nil a la propiedad oferta
            if let index = productos.firstIndex(where: { $0.id == productoID }) {
                productos[index].oferta = nil
            }
        }
    }
    // Función para revisar si un producto está en oferta
    func revisarOferta(productoID: Int) -> Bool {
        if let producto = productos.first(where: { $0.id == productoID }) {
            return producto.ofertaActivada
        }
        return false
    }
    
    // Función para realizar una venta y eliminar el producto del inventario
    mutating func realizarVenta(productoID: Int) -> Producto? {
        if let index = productos.firstIndex(where: { $0.id == productoID }) {
            let productoVendido = productos.remove(at: index)
            return productoVendido
        }
        return nil
    }
    
    // Función para revisar la disponibilidad de un producto
    func revisarDisponibilidad(productoID: Int) -> Int {
        if let producto = productos.first(where: { $0.id == productoID }) {
            return producto.disponibilidad
        }
        return 0
    }
    
    // Función para activar o desactivar la oferta de un producto
    mutating func activarDesactivarOferta(productoID: Int, activar: Bool) {
        if let index = productos.firstIndex(where: { $0.id == productoID }) {
            if activar {
                modificarOfertaProducto(productoID: productoID)
                //productos[index].oferta = .ocho
                productos[index].ofertaActivada = true
            } else {
                // Desactivar la oferta
                productos[index].oferta = nil
                productos[index].ofertaActivada = false
            }
        }
    }
}

// Función para pedir datos para un nuevo producto
func pedirDatosNuevoProducto() -> Producto {
    print("Ingrese el nombre del producto:")
    guard let nombre = readLine() else {
        fatalError("Nombre inválido")
    }
    print("Ingrese el precio del producto:")
    guard let precioString = readLine(), let precio = Double(precioString) else {
        fatalError("Precio inválido")
    }
    print("Ingrese el color del producto:")
    guard let color = readLine() else {
        fatalError("Color inválido")
    }
    print("Ingrese el ID del producto:")
    guard let idString = readLine(), let id = Int(idString) else {
        fatalError("ID inválido")
    }
    print("Ingrese la disponibilidad del producto:")
    guard let disponibilidadString = readLine(), let disponibilidad = Int(disponibilidadString) else {
        fatalError("Disponibilidad inválida")
    }
    
    
    return Producto(nombre: nombre, precio: precio, color: color, id: id, oferta: .none, ofertaActivada: false, disponibilidad: disponibilidad)
}


// Ejemplo de datos iniciales del inventario
var inventario = Inventario(productos: [
    Producto(nombre: "iPad Pro", precio: 999.99, color: "Silver", id: 1, oferta: .none, ofertaActivada: false, disponibilidad: 10),
    Producto(nombre: "iPhone 13", precio: 799.99, color: "Space Gray", id: 2, oferta: .ocho, ofertaActivada: true, disponibilidad: 5),
    Producto(nombre: "MacBook Air", precio: 1299.99, color: "Gold", id: 3, oferta: .quince, ofertaActivada: true, disponibilidad: 3)
])

func menu() -> String? {
    print("Menu: ")
    print("""
          0: Revisar inventario
          1: Registrar nuevo producto
          2: Revisar oferta en producto
          3: Realizar venta(Imprimir ticket y dinero de la tienda)
          4: Revisar disponibilidad en producto
          5: Activar Y Desactivar Ofertas
          6: Salir
          """)
    print("Opcion: ")
    if let opcion = readLine(){
        return opcion
    } else {
        return nil
    }
}

var run = true
while run == true{
    if let opcion = menu() {
        switch opcion {
        case "0":
            // Mostrar inventario
            print(inventario.productos)
            
        case "1":
            
            let nuevoProducto = pedirDatosNuevoProducto()
            inventario.registrarProducto(nuevoProducto)
            print("¿Oferta disponible? (true/false)")
            if let respuesta = readLine(), let activar = Bool(respuesta) {
                inventario.activarDesactivarOferta(productoID: nuevoProducto.id, activar: activar)
                print("Nuevo producto registrado:")
                print(inventario.productos.first(where: { $0.id == nuevoProducto.id }) ?? "Producto no encontrado")
            } else {
                if let productoVendido = inventario.realizarVenta(productoID: nuevoProducto.id) {
                    print("Respuesta invalida:")
                    //print(productoVendido)
                }
            }
            
        case "2":
            // Revisar oferta en producto
            print("Ingrese el ID del producto:")
            if let productoID = readLine(), let id = Int(productoID) {
                let oferta = inventario.revisarOferta(productoID: id)
                print(oferta ? "El producto está en oferta" : "El producto no está en oferta")
            }
            
        case "3":
            // Realizar venta
            print("Ingrese el ID del producto a vender:")
            if let productoID = readLine(), let id = Int(productoID) {
                if let productoVendido = inventario.realizarVenta(productoID: id) {
                    print("Venta realizada:")
                    print(productoVendido)
                } else {
                    print("Producto no encontrado en el inventario")
                }
            }
            
        case "4":
            // Revisar disponibilidad en producto
            print("Ingrese el ID del producto:")
            if let productoID = readLine(), let id = Int(productoID) {
                let disponibilidad = inventario.revisarDisponibilidad(productoID: id)
                print("Disponibilidad: \(disponibilidad)")
            }
            
        case "5":
            // Activar o desactivar oferta en producto
            print("Ingrese el ID del producto:")
            if let productoID = readLine(), let id = Int(productoID) {
                print("¿Desea activar o desactivar la oferta? (true/false)")
                if let respuesta = readLine(), let activar = Bool(respuesta) {
                    inventario.activarDesactivarOferta(productoID: id, activar: activar)
                    print("Oferta actualizada:")
                    print(inventario.productos.first(where: { $0.id == id }) ?? "Producto no encontrado")
                } else {
                    print("Respuesta inválida")
                }
            }
        case "6":
            print("Adios")
            run = false
            
        default:
            print("Opcion invalida")
        }
    }else {
            print("Opción inválida")
        }
    }

