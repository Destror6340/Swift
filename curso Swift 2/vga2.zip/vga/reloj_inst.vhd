reloj_inst : reloj PORT MAP (
		inclk0	 => inclk0_sig,
		c0	 => c0_sig
	);
