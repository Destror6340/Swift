library ieee;
use ieee.std_logic_1164.all;

entity vga is 
PORT (
	RI, GI, BI: in integer range 0 to 15;
	RO, GO, BO: out integer range 0 to 15;
	CLK, rst: in std_logic;
	SH, SV, clkprueba: out std_logic);
end entity;

architecture santafurro of vga is 
signal C1: integer range 0 to 799;
signal C2: integer range 0 to 521;
signal sel1, sel2, SHF: std_logic;
signal clk2: std_logic;

COMPONENT reloj IS
	PORT
	(
		inclk0		: IN STD_LOGIC  := '0';
		c0		: OUT STD_LOGIC 
	);
END component;


begin

reloj_principal: reloj port map (CLK, clk2);

process(clk2, rst)
begin
	clkprueba <= clk2;
	if rst = '1' then
		C1 <= 0;
		C2 <= 0;
		SH <= '1';
		SV <= '1';
	elsif rising_edge(clk2) then
		if C2 = 0 then 
			SV <= '0';
			RO <= 0;
			GO <= 0;
			BO <= 0;
		elsif C2 = 2 then 
			SV <= '1';
			RO <= 0;
			GO <= 0;
			BO <= 0;
		elsif C2 >= 31 then
			if C2 > 511 then 
				RO <= 0;
				GO <= 0;
				BO <= 0;
			else 
				if C1 = 0 then
					SH <= '0';
				elsif C1 = 96 then 
					SH <= '1';
					RO <= 0;
					GO <= 0;
					BO <= 0;
				elsif C1 = 144 then
					RO <= 7;
					GO <= 10;
					BO <= 5;
				elsif C1 = 784 then 
					RO <= 0;
					GO <= 0;
					BO <= 0;
				end if;
			end if;
		end if;
		C1 <= C1 + 1;
		if C1 = 799 then
			C2 <= C2 + 1;
			C1 <= 0;
		end if;
		if C2 = 522 then
			C2 <= 0;
		end if;
	end if;
end process;

--process (CLK) 
--begin 
--	if rising_edge(CLK) then 
--		clk2 <= NOT (clk2);
--	end if;
--end process;

--process (clk2, rst)
--begin
--	clkprueba <= clk2;
--	if rst = '1' then
--		C1 <= 0;
--		C2 <= 0;
--		SH <= '1';
--		SV <= '1';
--	elsif rising_edge(clk2) then
--		if C1 = 0 then 
--		SHF <= '0';
--		sel2 <= '0';
--		elsif C1 = 96 then
--			SHF <= '1';
--		elsif C1 = 144 then
--			sel2 <= '1';
--		elsif C1 = 784 then
--			sel2 <= '0';
--		end if;
--		
--		if C2 = 0 then
--			SV <= '0';
--			sel1 <= '0';
--		elsif C2 = 2 then 
--			SV <= '1';
--		elsif C2 = 33 then
--			sel1 <= '1';
--		elsif C2 = 515 then
--			sel1 <= '0';
--		end if;
--		C1 <= C1 + 1;
--		if C1 = 799 then
--			C2 <= C2 + 1;
--		end if;
--		if sel1 = '0' then 
--			SH <= '0';
--		else 
--			SH <= SHF;
--			if sel2 = '0' then
--			RO <= 0;
--			BO <= 0;
--			GO <= 0;
--		else 
--			RO <= RI;
--			BO <= BI;
--			GO <= GI;
--		end if;
--		end if;
--	end if;
--end process;

--process (C1, C2)
--begin
--	if C1 = 0 then 
--		SHF <= '0';
--		sel2 <= '0';
--	elsif C1 = 96 then
--		SHF <= '1';
--	elsif C1 = 144 then
--		sel2 <= '1';
--	elsif C1 = 784 then
--		sel2 <= '0';
--	end if;
--	
--	if C2 = 0 then
--		SV <= '0';
--		sel1 <= '0';
--	elsif C2 = 2 then 
--		SV <= '1';
--	elsif C2 = 33 then
--		sel1 <= '1';
--	elsif C2 = 515 then
--		sel1 <= '0';
--	end if;
--end process;
end santafurro;
		
		
		
	