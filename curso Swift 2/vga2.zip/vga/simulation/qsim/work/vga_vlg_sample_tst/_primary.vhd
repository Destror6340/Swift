library verilog;
use verilog.vl_types.all;
entity vga_vlg_sample_tst is
    port(
        BI              : in     vl_logic_vector(3 downto 0);
        CLK             : in     vl_logic;
        GI              : in     vl_logic_vector(3 downto 0);
        RI              : in     vl_logic_vector(3 downto 0);
        rst             : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end vga_vlg_sample_tst;
