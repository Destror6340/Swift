library verilog;
use verilog.vl_types.all;
entity vga_vlg_check_tst is
    port(
        BO              : in     vl_logic_vector(3 downto 0);
        GO              : in     vl_logic_vector(3 downto 0);
        RO              : in     vl_logic_vector(3 downto 0);
        SH              : in     vl_logic;
        SV              : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end vga_vlg_check_tst;
