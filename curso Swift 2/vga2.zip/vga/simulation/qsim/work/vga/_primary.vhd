library verilog;
use verilog.vl_types.all;
entity vga is
    port(
        RI              : in     vl_logic_vector(3 downto 0);
        GI              : in     vl_logic_vector(3 downto 0);
        BI              : in     vl_logic_vector(3 downto 0);
        RO              : out    vl_logic_vector(3 downto 0);
        GO              : out    vl_logic_vector(3 downto 0);
        BO              : out    vl_logic_vector(3 downto 0);
        CLK             : in     vl_logic;
        rst             : in     vl_logic;
        SH              : out    vl_logic;
        SV              : out    vl_logic
    );
end vga;
